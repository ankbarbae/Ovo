<?php
$telegram_id = "6761466528";
$id_bot = "7494226560:AAFQ6z2gfXDXGGKQpl_hNgQIPaTQYzMh3zs";
?>
